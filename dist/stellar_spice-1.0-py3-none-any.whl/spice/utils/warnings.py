class ExperimentalWarning(Warning):
    pass


class JAXWarning(Warning):
    pass